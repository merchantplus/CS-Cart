<?php

use Tygh\Http;
use Tygh\Registry;

if (!defined('BOOTSTRAP')) { die('Access denied'); }

$processor_error                = array();

//--> https://merchantplus.jira.com/wiki/display/NAVIGATE/Transaction+Response
$processor_error['avs']         = array(
						"A"     => "Address (Street) matches, ZIP does not",
						"B"     => "Address information not provided for AVS check",
						"E"     => "AVS error",
						"G"     => "Non-U.S. Card Issuing Bank",
						"N"     => "No Match on Address (Street) or ZIP",
						"P"     => "AVS not applicable for this transaction",
						"R"     => "Retry�System unavailable or timed out",
						"S"     => "Service not supported by issuer",
						"U"     => "Address information is unavailable",
						"W"     => "Nine digit ZIP matches, Address (Street) does not",
						"X"     => "Address (Street) and nine digit ZIP match",
						"Y"     => "Address (Street) and five digit ZIP match",
						"Z"     => "Five digit ZIP matches, Address (Street) does not"
);
$processor_error['cvv']         = array(
						"M"     => "Match",
						"N"     => "No Match",
						"P"     => "Not Processed",
						"S"     => "Should have been present",
						"U"     => "Issuer unable to process request"
);

$processor_error['order_status']= array(
						"1"     => "P",
						"2"     => "D",
						"3"     => "F"
);

$params                         = array();

// Merchant Info
$params['x_login']              = $processor_data['processor_params']['login'];
$params['x_tran_key']           = $processor_data['processor_params']['transaction_key'];

// TEST TRANSACTION
$params['x_test_request']       = ($processor_data['processor_params']['mode']== 'test' ? 'TRUE' : 'FALSE');

// AIM Head
$params['x_version']            = '3.1';

// TRUE Means that the Response is going to be delimited
$params['x_delim_data']         = 'TRUE';
$params['x_delim_char']         = '|';
$params['x_relay_response']     = 'FALSE';

// Transaction Info
$params['x_method']             = 'CC';
$params['x_type']               = $processor_data['processor_params']['transaction_type'];
$params['x_amount']             = fn_format_price($order_info['total']);

// Test Card    
$params['x_card_num']           = $order_info['payment_info']['card_number'];
$params['x_exp_date']           = $order_info['payment_info']['expiry_month'] . $order_info['payment_info']['expiry_year'];
$params['x_card_code']          = $order_info['payment_info']['cvv2'];
$params['x_trans_id']           = '';

// Order Info
$params['x_invoice_num']        = $processor_data['processor_params']['order_prefix'] . $order_id . (($order_info['repaid']) ? "_$order_info[repaid]" : '')  . '_' . fn_date_format(time(), '%H_%M_%S');
$params['x_description']        = '';

// Billing Info
$params['x_first_name']         = $order_info['b_firstname'];
$params['x_last_name']          = $order_info['b_lastname'];
$params['x_company']            = $order_info['company'];
$params['x_address']            = $order_info['b_address'];
$params['x_city']               = $order_info['b_city'];
$params['x_state']              = $order_info['b_state'];
$params['x_zip']                = $order_info['b_zipcode'];
$params['x_country']            = $order_info['b_country'];
$params['x_phone']              = $order_info['phone'];
$params['x_fax']                = $order_info['fax'];
$params['x_email']              = $order_info['email'];
$params['x_cust_id']            = $_SESSION['auth']['user_id'];
$params['x_customer_ip']        = $_SERVER['REMOTE_ADDR'];

// Shipping info
$params['x_ship_to_first_name'] = $order_info['firstname'];
$params['x_ship_to_last_name']  = $order_info['lastname'];
$params['x_ship_to_company']    = $order_info['company'];
$params['x_ship_to_address']    = $order_info['s_address'];
$params['x_ship_to_city']       = $order_info['s_city'];
$params['x_ship_to_state']      = $order_info['s_state'];
$params['x_ship_to_zip']        = $order_info['s_zipcode'];
$params['x_ship_to_country']    = $order_info['s_country'];

Registry::set('log_cut_data', array('x_card_num', 'x_exp_date', 'x_card_code'));
$url                            = 'https://gateway.merchantplus.com/cgi-bin/PAWebClient.cgi';
$__response                     = Http::post($url, $params);

if (!empty($__response)) {
	$delim                      = $__response{1};     
	$response_data              = explode($delim, $__response);
} else { //Not response
	$response_data              = array();
	$response_data[0]           = 3;
	$response_data[3]           = '';
}

$pp_response                    = array();
if (!empty($processor_error['order_status'][$response_data[0]])) {
	$pp_response['order_status']= $processor_error['order_status'][$response_data[0]];
} else {
	$pp_response['order_status']= 'F';
	$response_data[3]           = 'Processor does not reponse';
}

$pp_response['reason_text']     = $response_data[3];
$pp_response['transaction_id']  = (!empty($response_data[6])) ? $response_data[6] : '';
$pp_response['descr_avs']       = (!empty($response_data[5])) ? $processor_error['avs'][$response_data[5]] : '';
$pp_response['descr_cvv']       = (!empty($response_data[38])) ? $processor_error['cvv'][$response_data[38]] : '';